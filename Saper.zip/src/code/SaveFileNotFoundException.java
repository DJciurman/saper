package code;

import java.io.FileNotFoundException;

/**
 * Wyjątek rzucany gdy nie można odnaleźć odpowiedniego pliku z zapisaną grą
 */
public class SaveFileNotFoundException extends FileNotFoundException {
}
